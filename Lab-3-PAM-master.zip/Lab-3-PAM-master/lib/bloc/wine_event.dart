abstract class WineEvent {}

class LoadWines extends WineEvent {}
